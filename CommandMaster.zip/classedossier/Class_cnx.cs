﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace gstion_de_commande.classedossier
{
    internal class Class_cnx
    {
       
    }
}
